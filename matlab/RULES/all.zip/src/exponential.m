function y = exponential(x,theta,d)

y = exp(-(x-theta)/d)/d;
